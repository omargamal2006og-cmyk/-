import React from "react";
import { View, Text, StyleSheet } from "react-native";
import Card from "../components/Card";
import { calculateServiceCommission } from "../utils/commission";

export default function EarningsScreen({ t }) {
  const completedJobs = 3;
  const sampleJobPrice = 1000;
  const result = calculateServiceCommission(completedJobs, sampleJobPrice);

  const afterFiveJobs = calculateServiceCommission(5, sampleJobPrice);

  return (
    <View>
      <Text style={styles.h1}>{t.earnings}</Text>

      <Card>
        <Text style={styles.title}>{t.completedJobs}: {completedJobs}</Text>
        <Text>{t.freeJobsLeft}: {result.freeJobsLeft}</Text>
        <Text>{t.appCommission}: {result.appGets} EGP</Text>
        <Text>{t.providerGets}: {result.providerGets} EGP</Text>
      </Card>

      <Card>
        <Text style={styles.title}>Example after 5 free jobs</Text>
        <Text>Job price: {sampleJobPrice} EGP</Text>
        <Text>{t.appCommission}: {afterFiveJobs.appGets} EGP</Text>
        <Text>{t.providerGets}: {afterFiveJobs.providerGets} EGP</Text>
      </Card>
    </View>
  );
}

const styles = StyleSheet.create({
  h1: { fontSize: 24, fontWeight: "900", marginBottom: 12 },
  title: { fontSize: 18, fontWeight: "800", marginBottom: 6 }
});
