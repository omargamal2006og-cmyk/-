import React, { useState } from "react";
import { View, Text, TextInput, StyleSheet, Alert } from "react-native";
import Button from "../components/Button";

export default function RequestScreen({ t }) {
  const [title, setTitle] = useState("");
  return (
    <View>
      <Text style={styles.h1}>{t.postRequest}</Text>
      <TextInput style={styles.input} placeholder={t.title} value={title} onChangeText={setTitle} />
      <TextInput style={styles.input} placeholder={t.category} />
      <TextInput style={styles.input} placeholder={t.city} />
      <TextInput style={styles.input} placeholder={t.budget} keyboardType="number-pad" />
      <TextInput style={[styles.input, styles.big]} placeholder={t.details} multiline />
      <Button title={t.submit} onPress={() => Alert.alert(t.appName, "Request posted")} />
    </View>
  );
}

const styles = StyleSheet.create({
  h1: { fontSize: 24, fontWeight: "900", marginBottom: 12 },
  input: { backgroundColor: "white", padding: 14, borderRadius: 14, borderWidth: 1, borderColor: "#ddd", marginBottom: 10 },
  big: { height: 100, textAlignVertical: "top" }
});
