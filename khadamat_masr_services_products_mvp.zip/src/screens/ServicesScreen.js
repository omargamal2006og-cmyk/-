import React from "react";
import { View, Text, StyleSheet, Alert } from "react-native";
import Card from "../components/Card";
import Button from "../components/Button";
import { serviceRequests } from "../data/mockData";

export default function ServicesScreen({ t, lang }) {
  return (
    <View>
      <Text style={styles.h1}>{t.serviceRequests}</Text>
      {serviceRequests.map((job) => (
        <Card key={job.id}>
          <Text style={styles.title}>{lang === "ar" ? job.titleAr : job.title}</Text>
          <Text style={styles.meta}>{job.category} • {job.city} • {job.budget} EGP</Text>
          <Text style={styles.details}>{job.details}</Text>
          <Button title={t.sendOffer} onPress={() => Alert.alert(t.appName, "Offer sent")} />
        </Card>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  h1: { fontSize: 24, fontWeight: "900", marginBottom: 12 },
  title: { fontSize: 18, fontWeight: "800" },
  meta: { color: "#15803d", marginVertical: 6 },
  details: { color: "#555" }
});
