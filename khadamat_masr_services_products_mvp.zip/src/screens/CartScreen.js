import React from "react";
import { View, Text, StyleSheet, Alert } from "react-native";
import Card from "../components/Card";
import Button from "../components/Button";
import { calculateProductCommission } from "../utils/commission";

export default function CartScreen({ t, cart }) {
  const total = cart.reduce((sum, item) => sum + item.price, 0);
  const commission = calculateProductCommission(total);

  return (
    <View>
      <Text style={styles.h1}>{t.cart}</Text>
      {cart.length === 0 && <Card><Text>Your cart is empty.</Text></Card>}
      {cart.map((item, index) => (
        <Card key={index}><Text style={styles.title}>{item.name}</Text><Text>{item.price} EGP</Text></Card>
      ))}
      <Card>
        <Text style={styles.title}>Total: {total} EGP</Text>
        <Text>{t.appCommission}: {commission.appGets} EGP</Text>
        <Text>{t.sellerGets}: {commission.sellerGets} EGP</Text>
      </Card>
      <Button title={t.checkout} onPress={() => Alert.alert(t.appName, "Checkout coming soon")} />
    </View>
  );
}

const styles = StyleSheet.create({
  h1: { fontSize: 24, fontWeight: "900", marginBottom: 12 },
  title: { fontSize: 17, fontWeight: "800" }
});
