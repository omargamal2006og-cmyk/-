import React from "react";
import { View, Text, StyleSheet, Alert } from "react-native";
import Card from "../components/Card";
import Button from "../components/Button";
import { products } from "../data/mockData";

export default function StoreScreen({ t, lang, addToCart }) {
  return (
    <View>
      <Text style={styles.h1}>{t.products}</Text>
      {products.map((p) => (
        <Card key={p.id}>
          <Text style={styles.title}>{lang === "ar" ? p.nameAr : p.name}</Text>
          <Text style={styles.meta}>{p.category} • {p.price} EGP</Text>
          <Button title={t.addToCart} onPress={() => { addToCart(p); Alert.alert(t.appName, "Added to cart"); }} />
        </Card>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  h1: { fontSize: 24, fontWeight: "900", marginBottom: 12 },
  title: { fontSize: 18, fontWeight: "800" },
  meta: { color: "#15803d", marginVertical: 6 }
});
