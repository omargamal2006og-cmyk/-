import React from "react";
import { View, Text, StyleSheet } from "react-native";
import Card from "../components/Card";
import Button from "../components/Button";

export default function ProfileScreen({ t, role, setLogged }) {
  return (
    <View>
      <Text style={styles.h1}>{t.profile}</Text>
      <Card>
        <Text style={styles.name}>Omar</Text>
        <Text>{t[role]}</Text>
        <Text>⭐ 4.8</Text>
      </Card>
      <Button title={t.logout} secondary onPress={() => setLogged(false)} />
    </View>
  );
}

const styles = StyleSheet.create({
  h1: { fontSize: 24, fontWeight: "900", marginBottom: 12 },
  name: { fontSize: 22, fontWeight: "900", marginBottom: 6 }
});
