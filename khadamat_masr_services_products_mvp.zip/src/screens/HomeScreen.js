import React from "react";
import { View, Text, StyleSheet } from "react-native";
import Card from "../components/Card";

export default function HomeScreen({ t }) {
  return (
    <View>
      <Text style={styles.h1}>{t.appName}</Text>
      <Card><Text style={styles.bold}>{t.firstFive}</Text></Card>
      <Card><Text style={styles.bold}>{t.productPercent}</Text></Card>
      <Text style={styles.note}>MVP: services + products + commission logic included.</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  h1: { fontSize: 28, fontWeight: "900", marginBottom: 12 },
  bold: { fontSize: 16, fontWeight: "800" },
  note: { color: "#555", marginTop: 8 }
});
