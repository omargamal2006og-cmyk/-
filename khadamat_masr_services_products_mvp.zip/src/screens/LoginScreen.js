import React from "react";
import { View, Text, TextInput, TouchableOpacity, StyleSheet } from "react-native";
import Button from "../components/Button";

export default function LoginScreen({ t, lang, setLang, role, setRole, setLogged }) {
  return (
    <View style={styles.container}>
      <Text style={styles.logo}>خ</Text>
      <Text style={styles.title}>{t.loginTitle}</Text>
      <Text style={styles.sub}>{t.loginSub}</Text>

      <TouchableOpacity onPress={() => setLang(lang === "ar" ? "en" : "ar")}>
        <Text style={styles.lang}>{t.switchLang}</Text>
      </TouchableOpacity>

      <View style={styles.roles}>
        {["customer", "provider", "seller"].map((r) => (
          <TouchableOpacity key={r} style={[styles.role, role === r && styles.active]} onPress={() => setRole(r)}>
            <Text>{t[r]}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <TextInput style={styles.input} placeholder={t.phone} keyboardType="phone-pad" />
      <Button title={t.continue} onPress={() => setLogged(true)} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: "center", padding: 24, backgroundColor: "#f7f7f7" },
  logo: { alignSelf: "center", fontSize: 46, backgroundColor: "#15803d", color: "white", width: 84, height: 84, textAlign: "center", borderRadius: 22, paddingTop: 12, marginBottom: 14 },
  title: { fontSize: 28, fontWeight: "900", textAlign: "center" },
  sub: { color: "#555", textAlign: "center", marginVertical: 10 },
  lang: { color: "#15803d", fontWeight: "900", textAlign: "center", padding: 10 },
  roles: { flexDirection: "row", justifyContent: "center", gap: 8, marginVertical: 15 },
  role: { backgroundColor: "#e5e7eb", padding: 10, borderRadius: 12 },
  active: { backgroundColor: "#bbf7d0" },
  input: { backgroundColor: "white", padding: 14, borderRadius: 14, borderWidth: 1, borderColor: "#ddd", marginBottom: 8 }
});
