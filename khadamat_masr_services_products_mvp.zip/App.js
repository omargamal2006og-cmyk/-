import React, { useState } from "react";
import { SafeAreaView, View, Text, TouchableOpacity, ScrollView, StyleSheet } from "react-native";
import { StatusBar } from "expo-status-bar";
import { translations } from "./src/i18n/translations";

import LoginScreen from "./src/screens/LoginScreen";
import HomeScreen from "./src/screens/HomeScreen";
import ServicesScreen from "./src/screens/ServicesScreen";
import RequestScreen from "./src/screens/RequestScreen";
import StoreScreen from "./src/screens/StoreScreen";
import CartScreen from "./src/screens/CartScreen";
import EarningsScreen from "./src/screens/EarningsScreen";
import ProfileScreen from "./src/screens/ProfileScreen";

export default function App() {
  const [lang, setLang] = useState("ar");
  const [role, setRole] = useState("customer");
  const [logged, setLogged] = useState(false);
  const [screen, setScreen] = useState("home");
  const [cart, setCart] = useState([]);
  const t = translations[lang];

  function addToCart(product) {
    setCart([...cart, product]);
  }

  if (!logged) {
    return (
      <LoginScreen
        t={t}
        lang={lang}
        setLang={setLang}
        role={role}
        setRole={setRole}
        setLogged={setLogged}
      />
    );
  }

  function renderScreen() {
    if (screen === "home") return <HomeScreen t={t} />;
    if (screen === "services") return <ServicesScreen t={t} lang={lang} />;
    if (screen === "request") return <RequestScreen t={t} />;
    if (screen === "store") return <StoreScreen t={t} lang={lang} addToCart={addToCart} />;
    if (screen === "cart") return <CartScreen t={t} cart={cart} />;
    if (screen === "earnings") return <EarningsScreen t={t} />;
    if (screen === "profile") return <ProfileScreen t={t} role={role} setLogged={setLogged} />;
    return <HomeScreen t={t} />;
  }

  const nav = ["home", "services", "request", "store", "cart", "earnings", "profile"];

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar style="auto" />

      <View style={styles.header}>
        <Text style={styles.title}>{t.appName}</Text>
        <TouchableOpacity onPress={() => setLang(lang === "ar" ? "en" : "ar")}>
          <Text style={styles.lang}>{t.switchLang}</Text>
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.content}>{renderScreen()}</ScrollView>

      <View style={styles.nav}>
        {nav.map((item) => (
          <TouchableOpacity key={item} onPress={() => setScreen(item)} style={styles.navItem}>
            <Text style={[styles.navText, screen === item && styles.active]}>{t[item]}</Text>
          </TouchableOpacity>
        ))}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: "#f7f7f7" },
  header: { backgroundColor: "white", padding: 16, flexDirection: "row", justifyContent: "space-between", alignItems: "center", borderBottomWidth: 1, borderColor: "#e5e7eb" },
  title: { fontSize: 22, fontWeight: "900" },
  lang: { color: "#15803d", fontWeight: "900" },
  content: { padding: 16 },
  nav: { flexDirection: "row", justifyContent: "space-around", backgroundColor: "white", borderTopWidth: 1, borderColor: "#e5e7eb", paddingVertical: 8 },
  navItem: { padding: 3 },
  navText: { fontSize: 10, color: "#777" },
  active: { color: "#15803d", fontWeight: "900" }
});
