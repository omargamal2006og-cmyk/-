# Khadamat Masr MVP

Services + Products marketplace app starter.

## Business model included
- First 5 completed service jobs are free for each provider.
- After 5 jobs, service commission is 10%.
- Product sales commission is 5%.

## Included screens
- Login
- Home
- Services
- Create service request
- Store products
- Cart
- Earnings / commission
- Profile
- Arabic / English switch

## Run
```bash
npm install
npm start
```

This is an MVP starter. A real launch needs Firebase/Supabase, real authentication, payments, chat, maps, admin dashboard, privacy policy, and store review setup.
